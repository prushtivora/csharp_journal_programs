﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2_for_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 1, Space, Number;  
            Console.WriteLine("Print paramid");  
            for (int i = 1; i <= num; i++)   
            {  
                for (Space = 1; Space <= (num - i); Space++)  
                    Console.Write("1");  
                for (Number = 1; Number <= i; Number++)  
                    Console.Write("1,2");  
                for (Number = (i - 1); Number >= 1; Number--)  
                    Console.Write("1,2,3");  
                Console.ReadLine(); 
            }  
        }  
    }  
}  
        
    

