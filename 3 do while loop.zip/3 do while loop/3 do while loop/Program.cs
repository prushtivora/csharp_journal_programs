﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_do_while_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1, n = 3 product;

			do
			{
				product = n * i;
				Console.WriteLine("{0} * {1} = {2}", n, i, product);
				i++;
			} while (i <= 10);
            Console.ReadKey();
		}
	}
}
       
    

