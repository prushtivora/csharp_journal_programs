﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2_while_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
    i = 1;

    int sum = 0;
    while (i < 6)
    {
        for (j = 1; j <= i; j++)
        {

            Console.Write(i);
        }
        Console.Write("\n");
        sum += i;
        i++;

    }
    Console.ReadLine();
}
        }
    }

