﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace opretor
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 9;
            int y = 8;
            int sum;
            int subt;
            int mul;
            int dev;
            int mod;


            sum = x + y;
            subt = x - y;
            mul = x * y;
            dev = x / y;
            mod = x % y;

            Console.WriteLine(sum);
            Console.WriteLine(subt);
            Console.WriteLine(mul);
            Console.WriteLine(dev);
            Console.WriteLine(mod);
            Console.ReadLine();
        }
    }
}
