﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_FOR_LOOP
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;

for(;;)
{
    if (i < 10)
    {
        Console.WriteLine("Value of i: {0}", i);
        i++;
    }
    else
        break;
        }
    }
}
