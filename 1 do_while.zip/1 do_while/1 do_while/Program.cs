﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_do_while
{
    class Program
    {
        static void Main(string[] args)
        {
            int i ;

            do
            {
                Console.WriteLine("i++");
              

            } while (i < 1);
            Console.ReadLine();

        }
    }
}
