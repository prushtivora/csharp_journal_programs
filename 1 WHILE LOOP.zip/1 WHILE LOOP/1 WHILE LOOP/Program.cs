﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_WHILE_LOOP
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
			while (i<=5)
			{
				Console.WriteLine(i);
				i++;
                Console.ReadKey();
			}
		}
	}
}
        
    

